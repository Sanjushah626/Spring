package com.myshareapp.controller;

import com.myshareapp.entity.Contact;
import com.myshareapp.entity.News;
import com.myshareapp.entity.User;
import com.myshareapp.repository.ContactRepository;
import com.myshareapp.repository.NewsRepository;
import com.myshareapp.repository.PortfolioRepository;
import com.myshareapp.repository.UserRepository;
import com.myshareapp.service.NewsService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Controller
@PreAuthorize("hasRole('ADMIN')")
public class AdminWebController {

    private final UserRepository userRepository;
    private final PortfolioRepository portfolioRepository;
    private final NewsRepository newsRepository;
    private final ContactRepository contactRepository;
    private final NewsService newsService;

    public AdminWebController(UserRepository userRepository,
                              PortfolioRepository portfolioRepository,
                              NewsRepository newsRepository,
                              ContactRepository contactRepository,
                              NewsService newsService) {
        this.userRepository = userRepository;
        this.portfolioRepository = portfolioRepository;
        this.newsRepository = newsRepository;
        this.contactRepository = contactRepository;
        this.newsService = newsService;
    }

    public record AdminUserRow(Integer id, String username, String email, long portfolioCount, Instant createdAt) {}

    private void addCommon(Model model, String pageTitle, String currentPage, Authentication auth) {
        model.addAttribute("pageTitle", pageTitle);
        model.addAttribute("currentPage", currentPage);
        model.addAttribute("adminUsername", auth != null ? auth.getName() : "admin");
    }

    @GetMapping("/dashboard.php")
    public String dashboard(Authentication auth, Model model) {
        addCommon(model, "Dashboard", "dashboard.php", auth);
        List<AdminUserRow> recentUsers = userRepository.findTop5ByOrderByCreatedAtDesc().stream()
                .map(u -> new AdminUserRow(u.getId(), u.getUsername(), u.getEmail(), portfolioRepository.countByUserId(u.getId()), u.getCreatedAt()))
                .toList();

        model.addAttribute("totalUsers", userRepository.count());
        model.addAttribute("totalPortfolios", portfolioRepository.count());
        model.addAttribute("totalNews", newsRepository.count());
        model.addAttribute("totalContacts", contactRepository.count());
        model.addAttribute("recentUsers", recentUsers);
        model.addAttribute("latestContacts", contactRepository.findTop5ByOrderByCreatedAtDesc());
        model.addAttribute("latestNews", newsRepository.findTop5ByOrderByCreatedAtDesc());
        return "admin/dashboard";
    }

    @GetMapping("/users.php")
    public String users(@RequestParam(required = false) Integer delete, Authentication auth, Model model) {
        addCommon(model, "Users", "users.php", auth);
        String deleteMessage = "";
        String deleteMessageType = "success";

        if (delete != null) {
            User current = userRepository.findByUsername(auth.getName()).orElseThrow();
            if (current.getId().equals(delete)) {
                deleteMessage = "You cannot delete your own account.";
                deleteMessageType = "danger";
            } else {
                userRepository.deleteById(delete);
                deleteMessage = "User deleted successfully.";
                deleteMessageType = "success";
            }
        }

        List<AdminUserRow> users = userRepository.findAllByOrderByCreatedAtDesc().stream()
                .map(u -> new AdminUserRow(u.getId(), u.getUsername(), u.getEmail(), portfolioRepository.countByUserId(u.getId()), u.getCreatedAt()))
                .toList();

        model.addAttribute("users", users);
        model.addAttribute("deleteMessage", deleteMessage);
        model.addAttribute("deleteMessageType", deleteMessageType);
        return "admin/users";
    }

    @GetMapping("/newss.php")
    public String newsList(@RequestParam(defaultValue = "") String status, Authentication auth, Model model) {
        addCommon(model, "News Management", "newss.php", auth);
        model.addAttribute("newsList", newsRepository.findAllByOrderByCreatedAtDesc());
        model.addAttribute("status", status);
        return "admin/newss";
    }

    @GetMapping("/add_news.php")
    public String addNewsForm(Authentication auth, Model model) {
        addCommon(model, "Add News", "add_news.php", auth);
        model.addAttribute("errors", List.of());
        model.addAttribute("success", false);
        model.addAttribute("title", "");
        model.addAttribute("description", "");
        return "admin/add_news";
    }

    @PostMapping("/add_news.php")
    public String addNewsSubmit(@RequestParam(defaultValue = "") String title,
                                @RequestParam(defaultValue = "") String description,
                                @RequestParam(required = false) MultipartFile image,
                                Authentication auth,
                                Model model) {
        addCommon(model, "Add News", "add_news.php", auth);
        String cleanTitle = title.trim();
        String cleanDesc = description.trim();
        List<String> errors = new ArrayList<>();

        if (cleanTitle.isEmpty()) errors.add("Title is required.");
        else if (cleanTitle.length() > 255) errors.add("Title must be 255 characters or fewer.");
        if (cleanDesc.isEmpty()) errors.add("Description is required.");

        if (errors.isEmpty()) {
            try {
                User admin = userRepository.findByUsername(auth.getName()).orElseThrow();
                newsService.createNews(admin.getId(), cleanTitle, cleanDesc, image);
                model.addAttribute("errors", List.of());
                model.addAttribute("success", true);
                model.addAttribute("title", "");
                model.addAttribute("description", "");
                return "admin/add_news";
            } catch (Exception ex) {
                errors.add(ex.getMessage() != null ? ex.getMessage() : "Error uploading news.");
            }
        }

        model.addAttribute("errors", errors);
        model.addAttribute("success", false);
        model.addAttribute("title", cleanTitle);
        model.addAttribute("description", cleanDesc);
        return "admin/add_news";
    }

    @GetMapping("/edit_news.php")
    public String editNewsForm(@RequestParam Integer id, Authentication auth, Model model) {
        addCommon(model, "Edit News", "edit_news.php", auth);
        News news = newsRepository.findById(id).orElse(null);
        if (news == null) return "redirect:/newss.php";
        model.addAttribute("news", news);
        model.addAttribute("errors", List.of());
        model.addAttribute("title", news.getTitle());
        model.addAttribute("description", news.getDescription());
        return "admin/edit_news";
    }

    @PostMapping("/edit_news.php")
    public String editNewsSubmit(@RequestParam Integer id,
                                 @RequestParam(defaultValue = "") String title,
                                 @RequestParam(defaultValue = "") String description,
                                 @RequestParam(required = false) MultipartFile image,
                                 Authentication auth,
                                 Model model) {
        addCommon(model, "Edit News", "edit_news.php", auth);
        News news = newsRepository.findById(id).orElse(null);
        if (news == null) return "redirect:/newss.php";

        String cleanTitle = title.trim();
        String cleanDesc = description.trim();
        List<String> errors = new ArrayList<>();
        if (cleanTitle.isEmpty()) errors.add("Title is required.");
        else if (cleanTitle.length() > 255) errors.add("Title must be 255 characters or fewer.");
        if (cleanDesc.isEmpty()) errors.add("Description is required.");

        if (errors.isEmpty()) {
            try {
                newsService.updateNews(id, cleanTitle, cleanDesc, image);
                return "redirect:/newss.php?status=updated";
            } catch (Exception ex) {
                errors.add(ex.getMessage() != null ? ex.getMessage() : "Error updating news.");
            }
        }

        model.addAttribute("news", news);
        model.addAttribute("errors", errors);
        model.addAttribute("title", cleanTitle);
        model.addAttribute("description", cleanDesc);
        return "admin/edit_news";
    }

    @GetMapping("/delete_news.php")
    public String deleteNews(@RequestParam Integer id) {
        newsService.deleteNews(id);
        return "redirect:/newss.php?status=deleted";
    }

    @GetMapping("/contacts.php")
    public String contacts(@RequestParam(defaultValue = "") String status, Authentication auth, Model model) {
        addCommon(model, "Contact Messages", "contacts.php", auth);
        model.addAttribute("contacts", contactRepository.findAllByOrderByCreatedAtDesc());
        model.addAttribute("status", status);
        return "admin/contacts";
    }

    @GetMapping("/view_contact.php")
    public String viewContact(@RequestParam Integer id, Authentication auth, Model model) {
        addCommon(model, "View Message", "view_contact.php", auth);
        Contact contact = contactRepository.findById(id).orElse(null);
        if (contact == null) return "redirect:/contacts.php";
        model.addAttribute("contact", contact);
        return "admin/view_contact";
    }

    @GetMapping("/delete_contact.php")
    public String deleteContact(@RequestParam Integer id) {
        contactRepository.deleteById(id);
        return "redirect:/contacts.php?status=deleted";
    }
}
