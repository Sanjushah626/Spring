package com.myshareapp.controller;

import com.myshareapp.entity.Contact;
import com.myshareapp.entity.News;
import com.myshareapp.entity.User;
import com.myshareapp.repository.*;
import com.myshareapp.service.NewsService;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private final UserRepository userRepository;
    private final PortfolioRepository portfolioRepository;
    private final NewsRepository newsRepository;
    private final ContactRepository contactRepository;
    private final NewsService newsService;

    public AdminController(UserRepository userRepository,
                           PortfolioRepository portfolioRepository,
                           NewsRepository newsRepository,
                           ContactRepository contactRepository,
                           NewsService newsService) {
        this.userRepository = userRepository;
        this.portfolioRepository = portfolioRepository;
        this.newsRepository = newsRepository;
        this.contactRepository = contactRepository;
        this.newsService = newsService;
    }

    @GetMapping("/dashboard")
    public Map<String, Object> dashboard() {
        List<Map<String, Object>> recentUsers = userRepository.findTop5ByOrderByCreatedAtDesc().stream()
                .map(u -> Map.<String, Object>of(
                        "id", u.getId(),
                        "username", u.getUsername(),
                        "email", u.getEmail(),
                        "portfolioCount", portfolioRepository.countByUserId(u.getId()),
                        "createdAt", u.getCreatedAt()
                )).toList();

        return Map.of(
                "totalUsers", userRepository.count(),
                "totalPortfolios", portfolioRepository.count(),
                "totalNews", newsRepository.count(),
                "totalContacts", contactRepository.count(),
                "recentUsers", recentUsers,
                "latestContacts", contactRepository.findTop5ByOrderByCreatedAtDesc(),
                "latestNews", newsRepository.findTop5ByOrderByCreatedAtDesc()
        );
    }

    @GetMapping("/users")
    public List<Map<String, Object>> listUsers() {
        return userRepository.findAllByOrderByCreatedAtDesc().stream()
                .map(u -> Map.<String, Object>of(
                        "id", u.getId(),
                        "username", u.getUsername(),
                        "email", u.getEmail(),
                        "role", u.getRole().name(),
                        "portfolioCount", portfolioRepository.countByUserId(u.getId()),
                        "createdAt", u.getCreatedAt()
                )).toList();
    }

    @DeleteMapping("/users/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable Integer id, Authentication auth) {
        User current = userRepository.findByUsername(auth.getName()).orElseThrow();
        if (current.getId().equals(id)) {
            return ResponseEntity.badRequest().body(Map.of("error", "You cannot delete your own account."));
        }
        userRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/news")
    public List<News> listNews() {
        return newsRepository.findAllByOrderByCreatedAtDesc();
    }

    @PostMapping(value = "/news", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<News> createNews(@RequestParam String title,
                                           @RequestParam String description,
                                           @RequestParam(required = false) MultipartFile image,
                                           Authentication auth) throws IOException {
        User admin = userRepository.findByUsername(auth.getName()).orElseThrow();
        News created = newsService.createNews(admin.getId(), title, description, image);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PutMapping(value = "/news/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public News updateNews(@PathVariable Integer id,
                           @RequestParam String title,
                           @RequestParam String description,
                           @RequestParam(required = false) MultipartFile image) throws IOException {
        return newsService.updateNews(id, title, description, image);
    }

    @DeleteMapping("/news/{id}")
    public ResponseEntity<?> deleteNews(@PathVariable Integer id) {
        newsService.deleteNews(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/contacts")
    public List<Contact> listContacts() {
        return contactRepository.findAllByOrderByCreatedAtDesc();
    }

    @GetMapping("/contacts/{id}")
    public Contact viewContact(@PathVariable Integer id) {
        return contactRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Contact message not found."));
    }

    @DeleteMapping("/contacts/{id}")
    public ResponseEntity<?> deleteContact(@PathVariable Integer id) {
        contactRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
