package com.myshareapp.service;

import com.myshareapp.entity.News;
import com.myshareapp.repository.NewsRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;
import java.util.UUID;

@Service
public class NewsService {

    private static final Map<String, String> ALLOWED_TYPES = Map.of(
            "image/jpeg", "jpg",
            "image/png", "png",
            "image/gif", "gif",
            "image/webp", "webp"
    );

    private final NewsRepository newsRepository;
    private final Path uploadDir;

    public NewsService(NewsRepository newsRepository,
                       @Value("${app.upload.news-dir:uploads/news}") String uploadDirPath) {
        this.newsRepository = newsRepository;
        this.uploadDir = Paths.get(uploadDirPath).toAbsolutePath().normalize();
    }

    public News createNews(Integer userId, String title, String description, MultipartFile image) throws IOException {
        News news = new News();
        news.setUserId(userId);
        news.setTitle(title.trim());
        news.setDescription(description.trim());
        if (image != null && !image.isEmpty()) {
            news.setImage(saveImage(image));
        }
        return newsRepository.save(news);
    }

    public News updateNews(Integer id, String title, String description, MultipartFile image) throws IOException {
        News news = newsRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("News article not found."));
        news.setTitle(title.trim());
        news.setDescription(description.trim());
        if (image != null && !image.isEmpty()) {
            String newFileName = saveImage(image);
            deleteImageFile(news.getImage());
            news.setImage(newFileName);
        }
        return newsRepository.save(news);
    }

    public void deleteNews(Integer id) {
        newsRepository.findById(id).ifPresent(news -> {
            newsRepository.delete(news);
            deleteImageFile(news.getImage());
        });
    }

    private String saveImage(MultipartFile file) throws IOException {
        String ext = ALLOWED_TYPES.get(file.getContentType());
        if (ext == null) {
            throw new IllegalArgumentException("Only JPG, PNG, GIF and WEBP images are allowed.");
        }
        if (file.getSize() > 5L * 1024 * 1024) {
            throw new IllegalArgumentException("Image must be smaller than 5MB.");
        }
        Files.createDirectories(uploadDir);
        String filename = "news_" + UUID.randomUUID().toString().replace("-", "").substring(0, 16) + "." + ext;
        file.transferTo(uploadDir.resolve(filename));
        return filename;
    }

    private void deleteImageFile(String filename) {
        if (filename == null || filename.isBlank()) return;
        try {
            Files.deleteIfExists(uploadDir.resolve(filename));
        } catch (IOException ignored) {
        }
    }
}
