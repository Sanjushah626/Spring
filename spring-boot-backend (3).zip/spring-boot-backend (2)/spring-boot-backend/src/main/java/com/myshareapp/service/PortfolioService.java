package com.myshareapp.service;

import com.myshareapp.entity.Portfolio;
import com.myshareapp.repository.PortfolioRepository;
import com.myshareapp.repository.SoldStockRepository;
import com.myshareapp.repository.StockRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PortfolioService {

    private final PortfolioRepository portfolioRepository;
    private final StockRepository stockRepository;
    private final SoldStockRepository soldStockRepository;

    public PortfolioService(PortfolioRepository portfolioRepository,
                            StockRepository stockRepository,
                            SoldStockRepository soldStockRepository) {
        this.portfolioRepository = portfolioRepository;
        this.stockRepository = stockRepository;
        this.soldStockRepository = soldStockRepository;
    }

    @Transactional
    public void deletePortfolio(Integer userId, Integer portfolioId) {
        Portfolio portfolio = portfolioRepository.findByIdAndUserId(portfolioId, userId)
                .orElseThrow(() -> new IllegalArgumentException("Portfolio not found."));
        soldStockRepository.deleteByPortfolioId(portfolio.getId());
        stockRepository.deleteByPortfolioId(portfolio.getId());
        portfolioRepository.delete(portfolio);
    }
}
