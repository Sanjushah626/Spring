package com.myshareapp.service;

import com.myshareapp.entity.Portfolio;
import com.myshareapp.entity.SoldStock;
import com.myshareapp.entity.Stock;
import com.myshareapp.repository.PortfolioRepository;
import com.myshareapp.repository.SoldStockRepository;
import com.myshareapp.repository.StockRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class StockService {

    private final StockRepository stockRepository;
    private final PortfolioRepository portfolioRepository;
    private final SoldStockRepository soldStockRepository;

    public StockService(StockRepository stockRepository,
                        PortfolioRepository portfolioRepository,
                        SoldStockRepository soldStockRepository) {
        this.stockRepository = stockRepository;
        this.portfolioRepository = portfolioRepository;
        this.soldStockRepository = soldStockRepository;
    }

    @Transactional
    public Stock addStock(Integer userId, Integer portfolioId, String rawSymbol,
                          String purchaseType, Integer quantity, BigDecimal rawBuyPrice, LocalDate buyDate) {
        Portfolio portfolio = portfolioRepository.findByIdAndUserId(portfolioId, userId)
                .orElseThrow(() -> new IllegalArgumentException("Portfolio not found or access denied."));

        String symbol = rawSymbol.trim().toUpperCase();
        String type = (purchaseType == null || purchaseType.isBlank()) ? "Secondary" : purchaseType.trim();
        BigDecimal buyPrice = "Bonus".equalsIgnoreCase(type) ? BigDecimal.ZERO : rawBuyPrice;
        LocalDate effectiveDate = buyDate != null ? buyDate : LocalDate.now();

        return stockRepository.findByPortfolioIdAndSymbolForUpdate(portfolio.getId(), symbol)
                .map(existing -> {
                    int existingQty = existing.getQuantity();
                    BigDecimal existingPrice = existing.getBuyPrice();
                    int newQty = existingQty + quantity;

                    BigDecimal newAvgPrice = BigDecimal.ZERO;
                    if (newQty > 0) {
                        BigDecimal totalCost = existingPrice.multiply(BigDecimal.valueOf(existingQty))
                                .add(buyPrice.multiply(BigDecimal.valueOf(quantity)));
                        newAvgPrice = totalCost.divide(BigDecimal.valueOf(newQty), 2, RoundingMode.HALF_UP);
                    }

                    List<String> types = new ArrayList<>(Arrays.stream(existing.getPurchaseType().split("\\+"))
                            .map(String::trim)
                            .filter(s -> !s.isEmpty())
                            .toList());
                    if (!types.contains(type)) {
                        types.add(type);
                    }
                    existing.setPurchaseType(String.join("+", types));
                    existing.setQuantity(newQty);
                    existing.setBuyPrice(newAvgPrice);

                    if (existing.getBuyDate() == null || effectiveDate.isBefore(existing.getBuyDate())) {
                        existing.setBuyDate(effectiveDate);
                    }
                    return stockRepository.save(existing);
                })
                .orElseGet(() -> {
                    Stock s = new Stock();
                    s.setPortfolioId(portfolio.getId());
                    s.setSymbol(symbol);
                    s.setPurchaseType(type);
                    s.setQuantity(quantity);
                    s.setBuyPrice(buyPrice);
                    s.setBuyDate(effectiveDate);
                    return stockRepository.save(s);
                });
    }

    @Transactional
    public Stock editStock(Integer userId, Integer stockId, String rawSymbol,
                           String purchaseType, Integer quantity, BigDecimal rawBuyPrice, LocalDate buyDate) {
        Stock stock = stockRepository.findById(stockId)
                .orElseThrow(() -> new IllegalArgumentException("Stock not found."));
        portfolioRepository.findByIdAndUserId(stock.getPortfolioId(), userId)
                .orElseThrow(() -> new IllegalArgumentException("Access denied."));

        String type = (purchaseType == null || purchaseType.isBlank()) ? "Secondary" : purchaseType.trim();
        stock.setSymbol(rawSymbol.trim().toUpperCase());
        stock.setPurchaseType(type);
        stock.setQuantity(quantity);
        stock.setBuyPrice("Bonus".equalsIgnoreCase(type) ? BigDecimal.ZERO : rawBuyPrice);
        stock.setBuyDate(buyDate);
        return stockRepository.save(stock);
    }

    @Transactional
    public void deleteStock(Integer userId, Integer stockId) {
        Stock stock = stockRepository.findById(stockId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid stock."));
        Portfolio portfolio = portfolioRepository.findByIdAndUserId(stock.getPortfolioId(), userId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid stock."));

        List<SoldStock> sales = soldStockRepository.findByStockId(stockId);
        BigDecimal totalSaleValue = sales.stream()
                .map(SoldStock::getSaleValue)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal totalNetProfit = sales.stream()
                .map(SoldStock::getNetProfit)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        if (totalSaleValue.compareTo(BigDecimal.ZERO) > 0 || totalNetProfit.compareTo(BigDecimal.ZERO) != 0) {
            portfolio.setTotalSoldValue(portfolio.getTotalSoldValue().subtract(totalSaleValue));
            portfolio.setTotalRealizedProfit(portfolio.getTotalRealizedProfit().subtract(totalNetProfit));
            portfolioRepository.save(portfolio);
        }

        soldStockRepository.deleteByStockId(stockId);
        stockRepository.delete(stock);
    }

    @Transactional
    public SoldStock sellStock(Integer userId, Integer stockId, Integer sellQty,
                               BigDecimal sellPrice, LocalDate sellDate) {
        if (sellQty <= 0 || sellPrice.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Invalid input.");
        }

        Stock stock = stockRepository.findById(stockId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid stock."));
        Portfolio portfolio = portfolioRepository.findByIdAndUserId(stock.getPortfolioId(), userId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid stock."));

        if (sellQty > stock.getQuantity()) {
            throw new IllegalArgumentException("You can't sell more units than you currently hold.");
        }

        BigDecimal investmentCost = stock.getBuyPrice().multiply(BigDecimal.valueOf(sellQty)).setScale(2, RoundingMode.HALF_UP);
        BigDecimal saleValue = sellPrice.multiply(BigDecimal.valueOf(sellQty)).setScale(2, RoundingMode.HALF_UP);

        BigDecimal broker = brokerCommission(saleValue);
        BigDecimal sebon = saleValue.multiply(new BigDecimal("0.00015")).setScale(2, RoundingMode.HALF_UP);
        BigDecimal dp = new BigDecimal("25.00");
        BigDecimal sellChargesTotal = broker.add(sebon).add(dp);

        BigDecimal netReceivable = saleValue.subtract(sellChargesTotal);
        BigDecimal grossProfit = netReceivable.subtract(investmentCost);

        BigDecimal taxRate = capitalGainTaxRate(stock.getBuyDate(), portfolio.getPortfolioType());
        BigDecimal tax = grossProfit.compareTo(BigDecimal.ZERO) > 0
                ? grossProfit.multiply(taxRate).setScale(2, RoundingMode.HALF_UP)
                : BigDecimal.ZERO;
        BigDecimal netProfit = grossProfit.subtract(tax).setScale(2, RoundingMode.HALF_UP);

        SoldStock sold = new SoldStock();
        sold.setPortfolioId(portfolio.getId());
        sold.setStockId(stock.getId());
        sold.setSymbol(stock.getSymbol());
        sold.setQuantitySold(sellQty);
        sold.setBuyPrice(stock.getBuyPrice());
        sold.setSellPrice(sellPrice);
        sold.setInvestmentCost(investmentCost);
        sold.setSaleValue(saleValue);
        sold.setBrokerCharge(broker);
        sold.setSebonCharge(sebon);
        sold.setDpCharge(dp);
        sold.setCapitalGainTax(tax);
        sold.setNetProfit(netProfit);
        sold.setSellDate(sellDate != null ? sellDate : LocalDate.now());
        soldStockRepository.save(sold);

        stock.setQuantity(stock.getQuantity() - sellQty);
        stock.setSoldUnits(stock.getSoldUnits() + sellQty);
        stock.setSoldValue(stock.getSoldValue().add(saleValue));
        stockRepository.save(stock);

        portfolio.setTotalSoldValue(portfolio.getTotalSoldValue().add(saleValue));
        portfolio.setTotalRealizedProfit(portfolio.getTotalRealizedProfit().add(netProfit));
        portfolioRepository.save(portfolio);

        return sold;
    }

    private BigDecimal brokerCommission(BigDecimal amount) {
        BigDecimal rate;
        if (amount.compareTo(new BigDecimal("50000")) <= 0) rate = new BigDecimal("0.0036");
        else if (amount.compareTo(new BigDecimal("500000")) <= 0) rate = new BigDecimal("0.0033");
        else if (amount.compareTo(new BigDecimal("2000000")) <= 0) rate = new BigDecimal("0.0031");
        else if (amount.compareTo(new BigDecimal("10000000")) <= 0) rate = new BigDecimal("0.0027");
        else rate = new BigDecimal("0.0024");

        BigDecimal commission = amount.multiply(rate).setScale(2, RoundingMode.HALF_UP);
        return commission.compareTo(new BigDecimal("10.00")) < 0 ? new BigDecimal("10.00") : commission;
    }

    private BigDecimal capitalGainTaxRate(LocalDate buyDate, Portfolio.PortfolioType portfolioType) {
        if (portfolioType == Portfolio.PortfolioType.institutional || buyDate == null) {
            return new BigDecimal("0.10");
        }
        long holdingDays = ChronoUnit.DAYS.between(buyDate, LocalDate.now());
        return holdingDays >= 365 ? new BigDecimal("0.075") : new BigDecimal("0.10");
    }
}
