package com.myshareapp.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.*;

@RestController
public class NepseMarketController {

    private final String upstreamBaseUrl;
    private final HttpClient httpClient;

    public NepseMarketController(@Value("${nepse.api.base-url:}") String upstreamBaseUrl) {
        String trimmed = upstreamBaseUrl == null ? "" : upstreamBaseUrl.trim();
        while (trimmed.endsWith("/")) {
            trimmed = trimmed.substring(0, trimmed.length() - 1);
        }
        this.upstreamBaseUrl = trimmed;
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(4))
                .build();
    }

    private Optional<String> fetchFromUpstream(String pathWithQuery) {
        if (upstreamBaseUrl.isEmpty()) {
            return Optional.empty();
        }
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(upstreamBaseUrl + pathWithQuery))
                    .timeout(Duration.ofSeconds(6))
                    .header("Accept", "application/json")
                    .GET()
                    .build();
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() >= 200 && response.statusCode() < 300
                    && response.body() != null && !response.body().isBlank()) {
                return Optional.of(response.body());
            }
        } catch (Exception ignored) {
            // Fall back to built-in sample quotes if the live upstream server is offline
        }
        return Optional.empty();
    }

    private ResponseEntity<?> proxyOrFallback(String pathWithQuery, Object fallbackBody) {
        Optional<String> live = fetchFromUpstream(pathWithQuery);
        if (live.isPresent()) {
            return ResponseEntity.ok()
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(live.get());
        }
        return ResponseEntity.ok(fallbackBody);
    }

    private record StockQuote(
            String symbol,
            String securityName,
            double previousClose,
            double lastTradedPrice,
            double closePrice,
            double percentageChange,
            double pointChange,
            long shareTraded
    ) {}

    private static final List<StockQuote> MARKET_STOCKS = List.of(
            new StockQuote("NABIL", "Nabil Bank Limited", 512.00, 524.50, 524.50, 2.44, 12.50, 142310),
            new StockQuote("NICA", "NIC Asia Bank Ltd.", 418.00, 412.00, 412.00, -1.44, -6.00, 98500),
            new StockQuote("EBL", "Everest Bank Limited", 590.00, 604.00, 604.00, 2.37, 14.00, 76420),
            new StockQuote("SBI", "Nepal SBI Bank Limited", 398.00, 410.50, 410.50, 3.14, 12.50, 65300),
            new StockQuote("GBIME", "Global IME Bank Limited", 228.00, 231.40, 231.40, 1.49, 3.40, 215400),
            new StockQuote("PHCL", "Peoples Hydropower Company Ltd.", 294.00, 312.00, 312.00, 6.12, 18.00, 184220),
            new StockQuote("MEHL", "Manakamana Engineering Hydropower Ltd.", 348.00, 362.00, 362.00, 4.02, 14.00, 112050),
            new StockQuote("ANLB", "Aatmanirbhar Laghubitta Bittiya Sanstha Ltd.", 2180.00, 2125.00, 2125.00, -2.52, -55.00, 8420),
            new StockQuote("PCIL", "Pure Energy Limited", 685.00, 718.00, 718.00, 4.82, 33.00, 94110),
            new StockQuote("SOPL", "Sarbottam Cement Limited", 840.00, 865.00, 865.00, 2.98, 25.00, 67890),
            new StockQuote("AHPC", "Arun Valley Hydropower Dev. Co. Ltd.", 268.00, 279.00, 279.00, 4.10, 11.00, 245600),
            new StockQuote("UPPER", "Upper Tamakoshi Hydropower Ltd.", 214.00, 209.50, 209.50, -2.10, -4.50, 178900),
            new StockQuote("HIDCL", "Hydroelectricity Investment and Dev. Co.", 245.00, 242.00, 242.00, -1.22, -3.00, 156400),
            new StockQuote("API", "Api Power Company Ltd.", 256.00, 264.80, 264.80, 3.44, 8.80, 193000),
            new StockQuote("SHIVM", "SHIVAM CEMENTS LTD", 562.00, 549.00, 549.00, -2.31, -13.00, 134500),
            new StockQuote("NTC", "Nepal Doorsanchar Company Limited", 918.00, 932.00, 932.00, 1.53, 14.00, 54200),
            new StockQuote("UNL", "Unilever Nepal Limited", 45200.00, 46100.00, 46100.00, 1.99, 900.00, 620),
            new StockQuote("CBBL", "Chhimek Laghubitta Bittiya Sanstha Ltd.", 985.00, 1024.00, 1024.00, 3.96, 39.00, 43200)
    );

    private long getBaseSessionStartSec() {
        LocalDate today = LocalDate.now(ZoneOffset.UTC);
        return today.atTime(5, 15).toEpochSecond(ZoneOffset.UTC);
    }

    @GetMapping("/IsNepseOpen")
    public ResponseEntity<?> isNepseOpen() {
        return proxyOrFallback("/IsNepseOpen", Map.of("isOpen", "OPEN"));
    }

    @GetMapping("/DailyNepseIndexGraph")
    public ResponseEntity<?> getDailyNepseIndexGraph() {
        Optional<String> live = fetchFromUpstream("/DailyNepseIndexGraph");
        if (live.isPresent()) {
            return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(live.get());
        }
        long start = getBaseSessionStartSec();
        List<List<Number>> points = new ArrayList<>();
        double val = 2642.15;
        for (int i = 0; i <= 48; i++) {
            double delta = Math.sin(i * 0.35) * 3.8 + (i % 5 == 0 ? 2.1 : -0.6);
            val = Math.round((val + delta) * 100.0) / 100.0;
            points.add(List.of(start + i * 300L, val));
        }
        return ResponseEntity.ok(points);
    }

    @GetMapping("/TopTenTradeScrips")
    public ResponseEntity<?> getTopTenTradeScrips() {
        Optional<String> live = fetchFromUpstream("/TopTenTradeScrips");
        if (live.isPresent()) {
            return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(live.get());
        }
        List<Map<String, Object>> fallback = MARKET_STOCKS.stream()
                .sorted(Comparator.comparingLong(StockQuote::shareTraded).reversed())
                .limit(10)
                .map(s -> Map.<String, Object>of(
                        "symbol", s.symbol(),
                        "securityName", s.securityName(),
                        "shareTraded", s.shareTraded(),
                        "closingPrice", s.lastTradedPrice()
                ))
                .toList();
        return ResponseEntity.ok(fallback);
    }

    @GetMapping("/TopGainers")
    public ResponseEntity<?> getTopGainers() {
        Optional<String> live = fetchFromUpstream("/TopGainers");
        if (live.isPresent()) {
            return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(live.get());
        }
        List<Map<String, Object>> fallback = MARKET_STOCKS.stream()
                .filter(s -> s.percentageChange() > 0)
                .sorted(Comparator.comparingDouble(StockQuote::percentageChange).reversed())
                .limit(10)
                .map(s -> Map.<String, Object>of(
                        "symbol", s.symbol(),
                        "securityName", s.securityName(),
                        "ltp", s.lastTradedPrice(),
                        "pointChange", s.pointChange(),
                        "percentageChange", s.percentageChange()
                ))
                .toList();
        return ResponseEntity.ok(fallback);
    }

    @GetMapping("/TopLosers")
    public ResponseEntity<?> getTopLosers() {
        Optional<String> live = fetchFromUpstream("/TopLosers");
        if (live.isPresent()) {
            return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(live.get());
        }
        List<Map<String, Object>> fallback = MARKET_STOCKS.stream()
                .filter(s -> s.percentageChange() < 0)
                .sorted(Comparator.comparingDouble(StockQuote::percentageChange))
                .limit(10)
                .map(s -> Map.<String, Object>of(
                        "symbol", s.symbol(),
                        "securityName", s.securityName(),
                        "ltp", s.lastTradedPrice(),
                        "pointChange", s.pointChange(),
                        "percentageChange", s.percentageChange()
                ))
                .toList();
        return ResponseEntity.ok(fallback);
    }

    @GetMapping("/NepseIndex")
    public ResponseEntity<?> getNepseIndex() {
        return proxyOrFallback("/NepseIndex", Map.of(
                "NEPSE Index", Map.of("currentValue", 2678.42, "change", 36.27, "perChange", 1.37),
                "Sensitive Index", Map.of("currentValue", 482.19, "change", 5.84, "perChange", 1.23)
        ));
    }

    @GetMapping("/NepseSubIndices")
    public ResponseEntity<?> getNepseSubIndices() {
        return proxyOrFallback("/NepseSubIndices", Map.of(
                "Banking SubIndex", Map.of("currentValue", 1412.60, "change", 18.40, "perChange", 1.32),
                "HydroPower Index", Map.of("currentValue", 3185.25, "change", 54.10, "perChange", 1.73),
                "Finance Index", Map.of("currentValue", 2490.80, "change", -12.35, "perChange", -0.49),
                "Hotels And Tourism Index", Map.of("currentValue", 6140.15, "change", 42.90, "perChange", 0.70)
        ));
    }

    @GetMapping("/Summary")
    public ResponseEntity<?> getSummary() {
        return proxyOrFallback("/Summary", Map.of(
                "Total Turnover Rs:", 6428540120L,
                "Total Traded Shares", 14820450L,
                "Total Transactions", 72415L,
                "Total Scrips Traded", 312L,
                "Total Market Capitalization Rs:", 4285920140000L,
                "Total Float Market Capitalization Rs:", 1489210450000L
        ));
    }

    @GetMapping("/LiveMarket")
    public ResponseEntity<?> getLiveMarket() {
        return proxyOrFallback("/LiveMarket", MARKET_STOCKS);
    }

    @GetMapping("/PriceVolume")
    public ResponseEntity<?> getPriceVolume() {
        return proxyOrFallback("/PriceVolume", MARKET_STOCKS);
    }

    @GetMapping("/MarketDepth")
    public ResponseEntity<?> getMarketDepth(@RequestParam(defaultValue = "NABIL") String symbol) {
        String clean = symbol.trim().toUpperCase();
        String encoded = URLEncoder.encode(clean, StandardCharsets.UTF_8);
        Optional<String> live = fetchFromUpstream("/MarketDepth?symbol=" + encoded);
        if (live.isPresent()) {
            return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(live.get());
        }

        StockQuote stock = MARKET_STOCKS.stream()
                .filter(s -> s.symbol().equals(clean))
                .findFirst()
                .orElse(MARKET_STOCKS.get(0));

        double ltp = stock.lastTradedPrice();
        double step = ltp > 1000 ? 2.0 : 0.5;
        List<Map<String, Object>> buyList = new ArrayList<>();
        List<Map<String, Object>> sellList = new ArrayList<>();
        int totalBuyQty = 0;
        int totalSellQty = 0;

        for (int i = 0; i < 5; i++) {
            int bQty = (5 - i) * 320 + 140;
            int sQty = (i + 1) * 260 + 90;
            totalBuyQty += bQty;
            totalSellQty += sQty;
            buyList.add(Map.of(
                    "orderCount", 4 + i * 2,
                    "quantity", bQty,
                    "orderBookOrderPrice", Math.round((ltp - i * step) * 100.0) / 100.0
            ));
            sellList.add(Map.of(
                    "orderCount", 3 + i * 2,
                    "quantity", sQty,
                    "orderBookOrderPrice", Math.round((ltp + (i + 1) * step) * 100.0) / 100.0
            ));
        }

        return ResponseEntity.ok(Map.of(
                "totalBuyQty", totalBuyQty,
                "totalSellQty", totalSellQty,
                "marketDepth", Map.of(
                        "buyMarketDepthList", buyList,
                        "sellMarketDepthList", sellList
                )
        ));
    }

    @GetMapping("/DailyScripPriceGraph")
    public ResponseEntity<?> getDailyScripPriceGraph(@RequestParam(defaultValue = "NABIL") String symbol) {
        String clean = symbol.trim().toUpperCase();
        String encoded = URLEncoder.encode(clean, StandardCharsets.UTF_8);
        Optional<String> live = fetchFromUpstream("/DailyScripPriceGraph?symbol=" + encoded);
        if (live.isPresent()) {
            return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(live.get());
        }

        StockQuote stock = MARKET_STOCKS.stream()
                .filter(s -> s.symbol().equals(clean))
                .findFirst()
                .orElse(MARKET_STOCKS.get(0));

        long start = getBaseSessionStartSec();
        double base = stock.previousClose();
        double end = stock.lastTradedPrice();
        List<Map<String, Object>> points = new ArrayList<>();
        int steps = 24;
        for (int i = 0; i <= steps; i++) {
            double progress = (double) i / steps;
            double wave = Math.sin(i * 0.7) * (base * 0.006);
            double price = i == steps ? end : Math.round((base + (end - base) * progress + wave) * 100.0) / 100.0;
            points.add(Map.of(
                    "time", start + i * 600L,
                    "contractRate", price
            ));
        }
        return ResponseEntity.ok(points);
    }
}
