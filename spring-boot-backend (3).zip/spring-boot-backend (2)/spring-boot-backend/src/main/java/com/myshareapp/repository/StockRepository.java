package com.myshareapp.repository;

import com.myshareapp.entity.Stock;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;
import java.util.Optional;

public interface StockRepository extends JpaRepository<Stock, Integer> {
    List<Stock> findByPortfolioIdOrderBySymbolAsc(Integer portfolioId);
    long countByPortfolioId(Integer portfolioId);
    void deleteByPortfolioId(Integer portfolioId);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT s FROM Stock s WHERE s.portfolioId = :portfolioId AND s.symbol = :symbol")
    Optional<Stock> findByPortfolioIdAndSymbolForUpdate(@Param("portfolioId") Integer portfolioId, @Param("symbol") String symbol);
}
