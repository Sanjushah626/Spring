package com.myshareapp.controller;

import com.myshareapp.entity.Portfolio;
import com.myshareapp.entity.Stock;
import com.myshareapp.entity.User;
import com.myshareapp.repository.PortfolioRepository;
import com.myshareapp.repository.StockRepository;
import com.myshareapp.repository.UserRepository;
import com.myshareapp.service.PortfolioService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/portfolios")
public class PortfolioController {

    private final PortfolioRepository portfolioRepository;
    private final StockRepository stockRepository;
    private final UserRepository userRepository;
    private final PortfolioService portfolioService;

    public PortfolioController(PortfolioRepository portfolioRepository,
                               StockRepository stockRepository,
                               UserRepository userRepository,
                               PortfolioService portfolioService) {
        this.portfolioRepository = portfolioRepository;
        this.stockRepository = stockRepository;
        this.userRepository = userRepository;
        this.portfolioService = portfolioService;
    }

    public record PortfolioRequest(@NotBlank String portfolioName, String portfolioType) {}

    private User currentUser(Authentication auth) {
        return userRepository.findByUsername(auth.getName()).orElseThrow();
    }

    @GetMapping
    public List<Map<String, Object>> listPortfolios(Authentication auth) {
        User user = currentUser(auth);
        return portfolioRepository.findByUserId(user.getId()).stream().map(p -> {
            List<Stock> stocks = stockRepository.findByPortfolioIdOrderBySymbolAsc(p.getId());
            return Map.<String, Object>of(
                    "id", p.getId(),
                    "portfolioName", p.getPortfolioName(),
                    "portfolioType", p.getPortfolioType().name(),
                    "totalSoldValue", p.getTotalSoldValue(),
                    "totalRealizedProfit", p.getTotalRealizedProfit(),
                    "stocks", stocks
            );
        }).toList();
    }

    @PostMapping
    public ResponseEntity<Portfolio> createPortfolio(@Valid @RequestBody PortfolioRequest req, Authentication auth) {
        User user = currentUser(auth);
        Portfolio p = new Portfolio();
        p.setUserId(user.getId());
        p.setPortfolioName(req.portfolioName().trim());
        p.setPortfolioType("institutional".equalsIgnoreCase(req.portfolioType())
                ? Portfolio.PortfolioType.institutional
                : Portfolio.PortfolioType.personal);
        return ResponseEntity.status(HttpStatus.CREATED).body(portfolioRepository.save(p));
    }

    @PutMapping("/{id}")
    public Portfolio updatePortfolio(@PathVariable Integer id,
                                     @Valid @RequestBody PortfolioRequest req,
                                     Authentication auth) {
        User user = currentUser(auth);
        Portfolio p = portfolioRepository.findByIdAndUserId(id, user.getId())
                .orElseThrow(() -> new IllegalArgumentException("Portfolio not found."));
        p.setPortfolioName(req.portfolioName().trim());
        p.setPortfolioType("institutional".equalsIgnoreCase(req.portfolioType())
                ? Portfolio.PortfolioType.institutional
                : Portfolio.PortfolioType.personal);
        return portfolioRepository.save(p);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletePortfolio(@PathVariable Integer id, Authentication auth) {
        User user = currentUser(auth);
        portfolioService.deletePortfolio(user.getId(), id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/export")
    public ResponseEntity<byte[]> exportAllPortfolios(Authentication auth) {
        User user = currentUser(auth);
        List<Portfolio> portfolios = portfolioRepository.findByUserId(user.getId());
        return buildCsvResponse(portfolios, "myshareapp_all_portfolios.csv");
    }

    @GetMapping("/{id}/export")
    public ResponseEntity<byte[]> exportSinglePortfolio(@PathVariable Integer id, Authentication auth) {
        User user = currentUser(auth);
        Portfolio portfolio = portfolioRepository.findByIdAndUserId(id, user.getId())
                .orElseThrow(() -> new IllegalArgumentException("Portfolio not found."));
        String safeName = portfolio.getPortfolioName().replaceAll("[^a-zA-Z0-9_-]+", "_");
        return buildCsvResponse(List.of(portfolio), "myshareapp_" + safeName + ".csv");
    }

    private ResponseEntity<byte[]> buildCsvResponse(List<Portfolio> portfolios, String filename) {
        StringBuilder sb = new StringBuilder();
        sb.append("Portfolio,Type,Symbol,Purchase Type,Quantity,Avg Buy Price,Investment,Sold Units,Sold Value,Realized Profit,Buy Date\r\n");
        for (Portfolio p : portfolios) {
            List<Stock> stocks = stockRepository.findByPortfolioIdOrderBySymbolAsc(p.getId());
            if (stocks.isEmpty()) {
                sb.append(csvCell(p.getPortfolioName())).append(',')
                  .append(csvCell(p.getPortfolioType().name())).append(',')
                  .append("-,-,0,0.00,0.00,0,")
                  .append(p.getTotalSoldValue()).append(',')
                  .append(p.getTotalRealizedProfit()).append(",-\r\n");
                continue;
            }
            for (Stock s : stocks) {
                sb.append(csvCell(p.getPortfolioName())).append(',')
                  .append(csvCell(p.getPortfolioType().name())).append(',')
                  .append(csvCell(s.getSymbol())).append(',')
                  .append(csvCell(s.getPurchaseType())).append(',')
                  .append(s.getQuantity()).append(',')
                  .append(s.getBuyPrice()).append(',')
                  .append(s.getBuyPrice().multiply(java.math.BigDecimal.valueOf(s.getQuantity()))).append(',')
                  .append(s.getSoldUnits()).append(',')
                  .append(s.getSoldValue()).append(',')
                  .append(p.getTotalRealizedProfit()).append(',')
                  .append(csvCell(s.getBuyDate() != null ? s.getBuyDate().toString() : "-")).append("\r\n");
            }
        }
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
                .contentType(new MediaType("text", "csv", StandardCharsets.UTF_8))
                .body(sb.toString().getBytes(StandardCharsets.UTF_8));
    }

    private String csvCell(String val) {
        String s = val == null ? "" : val;
        if (s.contains(",") || s.contains("\"") || s.contains("\n") || s.contains("\r")) {
            return "\"" + s.replace("\"", "\"\"") + "\"";
        }
        return s;
    }
}
