package com.myshareapp.config;

import com.myshareapp.entity.*;
import com.myshareapp.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;

@Component
public class DataSeeder implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PortfolioRepository portfolioRepository;
    private final StockRepository stockRepository;
    private final SoldStockRepository soldStockRepository;
    private final NewsRepository newsRepository;
    private final ContactRepository contactRepository;

    public DataSeeder(
            UserRepository userRepository,
            PortfolioRepository portfolioRepository,
            StockRepository stockRepository,
            SoldStockRepository soldStockRepository,
            NewsRepository newsRepository,
            ContactRepository contactRepository
    ) {
        this.userRepository = userRepository;
        this.portfolioRepository = portfolioRepository;
        this.stockRepository = stockRepository;
        this.soldStockRepository = soldStockRepository;
        this.newsRepository = newsRepository;
        this.contactRepository = contactRepository;
    }

    @Override
    @Transactional
    public void run(String... args) {
        if (userRepository.count() > 0) {
            return;
        }

        User admin = saveUser("suraj", "suraj@gmail.com", "$2y$10$Ul5lxvW2z7ITKv4qj.vHVOf2YnuY2znk.KCTtZbfGC6BZTmRUGlj6", User.Role.admin);
        User sanju = saveUser("sanju", "sanju@gmail.com", "$2y$10$vFb.mTgNYy5.U3pP6OZ/qe4aurrTDsR/dQKL0CgmeutdnMvNnUWny", User.Role.user);
        User sarika = saveUser("sarika", "sarika@gmail.com", "$2y$10$BZ3CILqoyaPLV7tyOGIXT.yo3nOG2/lEmd2Li14aD8USG1be7rLWq", User.Role.user);
        User demoUser = saveUser("user", "user@gmail.com", "$2y$10$nlbDR6QRL6VuvVSe3.4LHu2hBU6BZrHv9wKEmpmHhtDyZ2sWKF9My", User.Role.user);

        Portfolio sanjuLongterm = savePortfolio(sanju.getId(), "longterm", Portfolio.PortfolioType.personal, new BigDecimal("35600.00"), new BigDecimal("5033.39"));
        Portfolio sanjuTest = savePortfolio(sanju.getId(), "test", Portfolio.PortfolioType.personal, BigDecimal.ZERO, BigDecimal.ZERO);
        Portfolio sarikaMain = savePortfolio(sarika.getId(), "sarika", Portfolio.PortfolioType.personal, new BigDecimal("254000.00"), new BigDecimal("-467275.45"));
        Portfolio sarikaPcil = savePortfolio(sarika.getId(), "pcil", Portfolio.PortfolioType.personal, BigDecimal.ZERO, BigDecimal.ZERO);
        Portfolio userLongterm = savePortfolio(demoUser.getId(), "longterm", Portfolio.PortfolioType.personal, BigDecimal.ZERO, BigDecimal.ZERO);

        saveStock(sanjuLongterm.getId(), "PHCL", "Secondary", 400, new BigDecimal("261.30"), LocalDate.of(2026, 1, 8), 0, BigDecimal.ZERO, 0);
        Stock mehl = saveStock(sanjuLongterm.getId(), "MEHL", "Secondary", 0, new BigDecimal("300.00"), null, 0, new BigDecimal("35600.00"), 100);
        saveStock(sanjuLongterm.getId(), "SOPL", "IPO", 10, new BigDecimal("100.00"), null, 0, BigDecimal.ZERO, 0);
        saveStock(sanjuTest.getId(), "AHPC", "Secondary", 145, new BigDecimal("254.00"), null, 0, BigDecimal.ZERO, 0);

        Stock ebl = saveStock(sarikaMain.getId(), "EBL", "Secondary", 0, new BigDecimal("198.00"), null, 0, new BigDecimal("54000.00"), 100);
        Stock anlb = saveStock(sarikaMain.getId(), "ANLB", "Secondary", 100, new BigDecimal("6980.00"), null, 0, new BigDecimal("200000.00"), 100);
        saveStock(sarikaPcil.getId(), "PCIL", "IPO", 10, new BigDecimal("100.00"), null, 0, BigDecimal.ZERO, 0);
        saveStock(userLongterm.getId(), "PHCL", "Secondary", 400, new BigDecimal("258.00"), null, 0, BigDecimal.ZERO, 0);

        saveSoldStock(sarikaMain.getId(), ebl.getId(), "EBL", 100, new BigDecimal("198.00"), new BigDecimal("540.00"), new BigDecimal("19800.00"), new BigDecimal("54000.00"), new BigDecimal("178.20"), new BigDecimal("8.10"), new BigDecimal("25.00"), new BigDecimal("2549.15"), new BigDecimal("31439.55"), LocalDate.of(2026, 7, 17));
        saveSoldStock(sanjuLongterm.getId(), mehl.getId(), "MEHL", 100, new BigDecimal("300.00"), new BigDecimal("356.00"), new BigDecimal("30000.00"), new BigDecimal("35600.00"), new BigDecimal("128.16"), new BigDecimal("5.34"), new BigDecimal("25.00"), new BigDecimal("408.11"), new BigDecimal("5033.39"), LocalDate.of(2026, 7, 18));
        saveSoldStock(sarikaMain.getId(), anlb.getId(), "ANLB", 100, new BigDecimal("6980.00"), new BigDecimal("2000.00"), new BigDecimal("698000.00"), new BigDecimal("200000.00"), new BigDecimal("660.00"), new BigDecimal("30.00"), new BigDecimal("25.00"), BigDecimal.ZERO, new BigDecimal("-498715.00"), LocalDate.of(2026, 7, 28));

        saveNews(admin.getId(), "Nepal SBI Bank Announces 8.25% Dividend for FY 2082/83", "Nepal SBI Bank has announced an 8.25% dividend for its shareholders, consisting of 3.4% bonus shares and 4.85% cash dividend.", "news_6a68dac04ed79.jpg");
        saveNews(admin.getId(), "Super Mai Hydropower Announces 18.421% Dividend", "Super Mai Hydropower has proposed an 18.421% dividend for FY 2082/83, including 14% bonus shares and 4.421% cash dividend.", null);
        saveNews(admin.getId(), "Unilever Nepal Announces 1540% Cash Dividend", "Unilever Nepal has recommended a 1540% cash dividend for FY 2082/83, equivalent to Rs. 1,540 per equity share.", null);
        saveNews(admin.getId(), "Api Power Announces 5.2632% Dividend", "Api Power Company has proposed a 5.2632% total dividend for FY 2082/83, consisting of 5% bonus shares and 0.2632% cash dividend.", null);
        saveNews(admin.getId(), "Chhimek Laghubitta Announces 25% Dividend", "Chhimek Laghubitta has declared a 25% dividend for FY 2082/83, comprising 11.9631% bonus shares and 13.0369% cash dividend.", null);

        saveContact("sanju", "sanju@gmail.com", "test", "testing if it is working or not");
        saveContact("sanju", "sanju@gmail.com", "upload some news", "news tab is empty upload smoke news");
        saveContact("sarika", "sarika@gmail.com", "Review", "5 start");
        saveContact("sanju", "ashim@gmail.com", "ex", "python cobra sab thin uni");
    }

    private User saveUser(String username, String email, String passwordHash, User.Role role) {
        User u = new User();
        u.setUsername(username);
        u.setEmail(email);
        u.setPassword(passwordHash);
        u.setRole(role);
        u.setCreatedAt(Instant.now());
        return userRepository.save(u);
    }

    private Portfolio savePortfolio(Integer userId, String name, Portfolio.PortfolioType type, BigDecimal soldVal, BigDecimal realizedProfit) {
        Portfolio p = new Portfolio();
        p.setUserId(userId);
        p.setPortfolioName(name);
        p.setPortfolioType(type);
        p.setTotalSoldValue(soldVal);
        p.setTotalRealizedProfit(realizedProfit);
        return portfolioRepository.save(p);
    }

    private Stock saveStock(Integer portfolioId, String symbol, String purchaseType, int qty, BigDecimal buyPrice, LocalDate buyDate, int soldQty, BigDecimal soldVal, int soldUnits) {
        Stock s = new Stock();
        s.setPortfolioId(portfolioId);
        s.setSymbol(symbol);
        s.setPurchaseType(purchaseType);
        s.setQuantity(qty);
        s.setBuyPrice(buyPrice);
        s.setBuyDate(buyDate);
        s.setSoldQuantity(soldQty);
        s.setSoldValue(soldVal);
        s.setSoldUnits(soldUnits);
        return stockRepository.save(s);
    }

    private void saveSoldStock(Integer portfolioId, Integer stockId, String symbol, int qtySold, BigDecimal buyPrice, BigDecimal sellPrice, BigDecimal invCost, BigDecimal saleVal, BigDecimal broker, BigDecimal sebon, BigDecimal dp, BigDecimal cgt, BigDecimal netProfit, LocalDate sellDate) {
        SoldStock ss = new SoldStock();
        ss.setPortfolioId(portfolioId);
        ss.setStockId(stockId);
        ss.setSymbol(symbol);
        ss.setQuantitySold(qtySold);
        ss.setBuyPrice(buyPrice);
        ss.setSellPrice(sellPrice);
        ss.setInvestmentCost(invCost);
        ss.setSaleValue(saleVal);
        ss.setBrokerCharge(broker);
        ss.setSebonCharge(sebon);
        ss.setDpCharge(dp);
        ss.setCapitalGainTax(cgt);
        ss.setNetProfit(netProfit);
        ss.setSellDate(sellDate);
        ss.setCreatedAt(Instant.now());
        soldStockRepository.save(ss);
    }

    private void saveNews(Integer userId, String title, String description, String image) {
        News n = new News();
        n.setUserId(userId);
        n.setTitle(title);
        n.setDescription(description);
        n.setImage(image);
        n.setCreatedAt(Instant.now());
        newsRepository.save(n);
    }

    private void saveContact(String name, String email, String subject, String message) {
        Contact c = new Contact();
        c.setName(name);
        c.setEmail(email);
        c.setSubject(subject);
        c.setMessage(message);
        c.setCreatedAt(Instant.now());
        contactRepository.save(c);
    }
}
