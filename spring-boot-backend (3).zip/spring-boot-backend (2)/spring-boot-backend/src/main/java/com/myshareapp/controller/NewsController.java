package com.myshareapp.controller;

import com.myshareapp.entity.News;
import com.myshareapp.repository.NewsRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
@RequestMapping("/api/news")
public class NewsController {

    private final NewsRepository newsRepository;

    public NewsController(NewsRepository newsRepository) {
        this.newsRepository = newsRepository;
    }

    @GetMapping
    public List<News> listLatestNews() {
        return newsRepository.findTop50ByOrderByCreatedAtDesc();
    }
}
