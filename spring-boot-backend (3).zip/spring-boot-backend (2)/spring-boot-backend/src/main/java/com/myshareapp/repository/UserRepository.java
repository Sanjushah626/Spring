package com.myshareapp.repository;

import com.myshareapp.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Integer> {
    Optional<User> findByUsername(String username);
    boolean existsByUsernameOrEmail(String username, String email);
    List<User> findTop5ByOrderByCreatedAtDesc();
    List<User> findAllByOrderByCreatedAtDesc();
}
