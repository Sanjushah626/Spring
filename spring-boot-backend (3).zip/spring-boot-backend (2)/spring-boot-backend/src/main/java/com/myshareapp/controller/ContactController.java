package com.myshareapp.controller;

import com.myshareapp.entity.Contact;
import com.myshareapp.repository.ContactRepository;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/contacts")
public class ContactController {

    private final ContactRepository contactRepository;

    public ContactController(ContactRepository contactRepository) {
        this.contactRepository = contactRepository;
    }

    public record ContactRequest(
            @NotBlank String name,
            @NotBlank @Email String email,
            String subject,
            @NotBlank String message
    ) {}

    @PostMapping
    public ResponseEntity<Contact> submitContact(@Valid @RequestBody ContactRequest req) {
        Contact contact = new Contact();
        contact.setName(req.name().trim());
        contact.setEmail(req.email().trim());
        contact.setSubject(req.subject() != null ? req.subject().trim() : "");
        contact.setMessage(req.message().trim());
        return ResponseEntity.status(HttpStatus.CREATED).body(contactRepository.save(contact));
    }
}
