package com.myshareapp.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(
    name = "portfolios",
    uniqueConstraints = @UniqueConstraint(name = "unique_user_portfolio", columnNames = {"user_id", "portfolio_name"})
)
public class Portfolio {

    public enum PortfolioType {
        personal, institutional
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "user_id", nullable = false)
    private Integer userId;

    @Column(name = "portfolio_name", nullable = false, length = 100)
    private String portfolioName;

    @Enumerated(EnumType.STRING)
    @Column(name = "portfolio_type", nullable = false)
    private PortfolioType portfolioType = PortfolioType.personal;

    @Column(name = "total_sold_value", nullable = false, precision = 15, scale = 2)
    private BigDecimal totalSoldValue = BigDecimal.ZERO;

    @Column(name = "total_realized_profit", nullable = false, precision = 15, scale = 2)
    private BigDecimal totalRealizedProfit = BigDecimal.ZERO;

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }
    public String getPortfolioName() { return portfolioName; }
    public void setPortfolioName(String portfolioName) { this.portfolioName = portfolioName; }
    public PortfolioType getPortfolioType() { return portfolioType; }
    public void setPortfolioType(PortfolioType portfolioType) { this.portfolioType = portfolioType; }
    public BigDecimal getTotalSoldValue() { return totalSoldValue; }
    public void setTotalSoldValue(BigDecimal totalSoldValue) { this.totalSoldValue = totalSoldValue; }
    public BigDecimal getTotalRealizedProfit() { return totalRealizedProfit; }
    public void setTotalRealizedProfit(BigDecimal totalRealizedProfit) { this.totalRealizedProfit = totalRealizedProfit; }
}
