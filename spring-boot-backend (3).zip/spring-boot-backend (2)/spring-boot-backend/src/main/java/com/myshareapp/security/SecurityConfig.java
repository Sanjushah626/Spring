package com.myshareapp.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableMethodSecurity
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new PhpCompatiblePasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .headers(headers -> headers.frameOptions(frame -> frame.sameOrigin()))
            .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers(
                    "/", "/hello.html", "/market.html",
                    "/news.php", "/news", "/contact.php", "/contact",
                    "/login.php", "/login", "/signup.php", "/signup",
                    "/style.css", "/styles.css", "/script.js", "/1.js", "/scripts.js",
                    "/uploads/**", "/favicon.ico", "/error", "/h2-console/**",
                    "/IsNepseOpen", "/DailyNepseIndexGraph", "/TopTenTradeScrips",
                    "/TopGainers", "/TopLosers", "/NepseIndex", "/NepseSubIndices",
                    "/Summary", "/LiveMarket", "/PriceVolume", "/MarketDepth", "/DailyScripPriceGraph"
                ).permitAll()
                .requestMatchers("/api/auth/**").permitAll()
                .requestMatchers(HttpMethod.GET, "/api/news").permitAll()
                .requestMatchers(HttpMethod.POST, "/api/contacts").permitAll()
                .requestMatchers(
                    "/dashboard.php", "/users.php", "/newss.php",
                    "/add_news.php", "/edit_news.php", "/delete_news.php",
                    "/contacts.php", "/view_contact.php", "/delete_contact.php",
                    "/api/admin/**"
                ).hasRole("ADMIN")
                .requestMatchers(
                    "/portfolio.php", "/portfolio",
                    "/add_portfolio.php", "/edit_portfolio.php", "/delete_portfolio.php",
                    "/export_portfolio.php", "/export_portfolio",
                    "/add_stock.php", "/edit_stock.php", "/delete_stock.php", "/sell_stock.php",
                    "/api/portfolios/**", "/api/stocks/**"
                ).authenticated()
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .loginPage("/login.php")
                .loginProcessingUrl("/login.php")
                .successHandler((request, response, authentication) -> {
                    boolean isAdmin = authentication.getAuthorities().stream()
                            .anyMatch(a -> "ROLE_ADMIN".equals(a.getAuthority()));
                    response.sendRedirect(isAdmin ? "/dashboard.php" : "/hello.html");
                })
                .failureUrl("/login.php?error=true")
                .permitAll()
            )
            .logout(logout -> logout
                .logoutRequestMatcher(new AntPathRequestMatcher("/logout.php"))
                .logoutSuccessUrl("/login.php")
                .invalidateHttpSession(true)
                .deleteCookies("JSESSIONID")
                .permitAll()
            );
        return http.build();
    }
}
