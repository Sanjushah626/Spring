package com.myshareapp.repository;

import com.myshareapp.entity.News;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface NewsRepository extends JpaRepository<News, Integer> {
    List<News> findTop50ByOrderByCreatedAtDesc();
    List<News> findTop5ByOrderByCreatedAtDesc();
    List<News> findAllByOrderByCreatedAtDesc();
}
