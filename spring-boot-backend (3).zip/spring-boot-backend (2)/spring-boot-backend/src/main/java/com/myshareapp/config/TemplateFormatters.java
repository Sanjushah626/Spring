package com.myshareapp.config;

import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

@Component("fmt")
public class TemplateFormatters {

    private static final DateTimeFormatter SHORT_DATE =
            DateTimeFormatter.ofPattern("MMM dd, yyyy").withZone(ZoneId.systemDefault());

    private static final DateTimeFormatter DATE_TIME =
            DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm a").withZone(ZoneId.systemDefault());

    public String money(Number value) {
        double v = value != null ? value.doubleValue() : 0.0;
        DecimalFormat df = new DecimalFormat("#,##0.00");
        return df.format(v);
    }

    public String shortDate(Instant instant) {
        if (instant == null) return "-";
        return SHORT_DATE.format(instant);
    }

    public String dateTime(Instant instant) {
        if (instant == null) return "-";
        return DATE_TIME.format(instant);
    }

    public String initial(String text) {
        if (text == null || text.isBlank()) return "U";
        return text.trim().substring(0, 1).toUpperCase();
    }

    public String truncate(String text, int max) {
        if (text == null) return "";
        return text.length() > max ? text.substring(0, max) + "..." : text;
    }

    public String urlEncode(String text) {
        if (text == null) return "";
        return java.net.URLEncoder.encode(text, java.nio.charset.StandardCharsets.UTF_8);
    }
}
