package com.myshareapp.security;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * Verifies both standard Spring $2a$/$2b$ hashes and existing PHP password_hash() $2y$ hashes
 * from myshareapp.sql without requiring existing users to reset passwords.
 */
public class PhpCompatiblePasswordEncoder implements PasswordEncoder {

    private final BCryptPasswordEncoder delegate = new BCryptPasswordEncoder();

    @Override
    public String encode(CharSequence rawPassword) {
        return delegate.encode(rawPassword);
    }

    @Override
    public boolean matches(CharSequence rawPassword, String encodedPassword) {
        if (encodedPassword == null) return false;
        String normalized = encodedPassword.startsWith("$2y$")
                ? "$2a$" + encodedPassword.substring(4)
                : encodedPassword;
        return delegate.matches(rawPassword, normalized);
    }
}
