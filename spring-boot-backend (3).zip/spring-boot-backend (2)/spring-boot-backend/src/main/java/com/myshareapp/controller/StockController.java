package com.myshareapp.controller;

import com.myshareapp.entity.SoldStock;
import com.myshareapp.entity.Stock;
import com.myshareapp.entity.User;
import com.myshareapp.repository.UserRepository;
import com.myshareapp.service.StockService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;

@RestController
@RequestMapping("/api/stocks")
public class StockController {

    private final StockService stockService;
    private final UserRepository userRepository;

    public StockController(StockService stockService, UserRepository userRepository) {
        this.stockService = stockService;
        this.userRepository = userRepository;
    }

    public record AddStockRequest(
            @NotNull Integer portfolioId,
            @NotBlank String symbol,
            String purchaseType,
            @NotNull @Min(1) Integer quantity,
            BigDecimal buyPrice,
            LocalDate buyDate
    ) {}

    public record EditStockRequest(
            @NotBlank String symbol,
            String purchaseType,
            @NotNull @Min(0) Integer quantity,
            BigDecimal buyPrice,
            LocalDate buyDate
    ) {}

    public record SellStockRequest(
            @NotNull @Min(1) Integer sellQuantity,
            @NotNull BigDecimal sellPrice,
            LocalDate sellDate
    ) {}

    private Integer currentUserId(Authentication auth) {
        User user = userRepository.findByUsername(auth.getName()).orElseThrow();
        return user.getId();
    }

    @PostMapping
    public ResponseEntity<Stock> addStock(@Valid @RequestBody AddStockRequest req, Authentication auth) {
        Stock saved = stockService.addStock(
                currentUserId(auth),
                req.portfolioId(),
                req.symbol(),
                req.purchaseType(),
                req.quantity(),
                req.buyPrice() != null ? req.buyPrice() : BigDecimal.ZERO,
                req.buyDate()
        );
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    @PutMapping("/{id}")
    public Stock editStock(@PathVariable Integer id,
                           @Valid @RequestBody EditStockRequest req,
                           Authentication auth) {
        return stockService.editStock(
                currentUserId(auth),
                id,
                req.symbol(),
                req.purchaseType(),
                req.quantity(),
                req.buyPrice() != null ? req.buyPrice() : BigDecimal.ZERO,
                req.buyDate()
        );
    }

    @PostMapping("/{id}/sell")
    public SoldStock sellStock(@PathVariable Integer id,
                               @Valid @RequestBody SellStockRequest req,
                               Authentication auth) {
        return stockService.sellStock(
                currentUserId(auth),
                id,
                req.sellQuantity(),
                req.sellPrice(),
                req.sellDate()
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteStock(@PathVariable Integer id, Authentication auth) {
        stockService.deleteStock(currentUserId(auth), id);
        return ResponseEntity.noContent().build();
    }
}
