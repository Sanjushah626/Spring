package com.myshareapp.controller;

import com.myshareapp.entity.Contact;
import com.myshareapp.entity.Portfolio;
import com.myshareapp.entity.Stock;
import com.myshareapp.entity.User;
import com.myshareapp.repository.ContactRepository;
import com.myshareapp.repository.NewsRepository;
import com.myshareapp.repository.PortfolioRepository;
import com.myshareapp.repository.StockRepository;
import com.myshareapp.repository.UserRepository;
import com.myshareapp.service.PortfolioService;
import com.myshareapp.service.StockService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

@Controller
public class WebPageController {

    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$");

    private final UserRepository userRepository;
    private final PortfolioRepository portfolioRepository;
    private final StockRepository stockRepository;
    private final NewsRepository newsRepository;
    private final ContactRepository contactRepository;
    private final PortfolioService portfolioService;
    private final StockService stockService;
    private final PasswordEncoder passwordEncoder;

    public WebPageController(UserRepository userRepository,
                             PortfolioRepository portfolioRepository,
                             StockRepository stockRepository,
                             NewsRepository newsRepository,
                             ContactRepository contactRepository,
                             PortfolioService portfolioService,
                             StockService stockService,
                             PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.portfolioRepository = portfolioRepository;
        this.stockRepository = stockRepository;
        this.newsRepository = newsRepository;
        this.contactRepository = contactRepository;
        this.portfolioService = portfolioService;
        this.stockService = stockService;
        this.passwordEncoder = passwordEncoder;
    }

    public record StockView(
            Integer id,
            String symbol,
            String purchaseType,
            String purchaseTypeLower,
            int quantity,
            BigDecimal buyPrice,
            BigDecimal investment,
            String buyDate,
            int soldUnits,
            BigDecimal soldValue,
            boolean soldOut
    ) {}

    public record PortfolioView(
            Integer id,
            String portfolioName,
            String portfolioType,
            BigDecimal totalInvestment,
            int totalUnits,
            BigDecimal totalSoldValue,
            BigDecimal totalRealizedProfit,
            BigDecimal totalRealizedAbs,
            String realizedLabel,
            String realizedClass,
            List<StockView> stocks
    ) {}

    @ModelAttribute("loggedIn")
    public boolean loggedIn(Authentication auth) {
        return auth != null && auth.isAuthenticated() && !(auth instanceof AnonymousAuthenticationToken);
    }

    private User requireCurrentUser(Authentication auth) {
        return userRepository.findByUsername(auth.getName()).orElseThrow();
    }

    @GetMapping({"/", "/hello.html"})
    public String home() {
        return "hello";
    }

    @GetMapping("/market.html")
    public String market() {
        return "market";
    }

    @GetMapping({"/news.php", "/news"})
    public String news(Model model) {
        model.addAttribute("news", newsRepository.findTop50ByOrderByCreatedAtDesc());
        return "news";
    }

    @GetMapping({"/contact.php", "/contact"})
    public String contactForm(Authentication auth, Model model) {
        String prefillName = "";
        String prefillEmail = "";
        if (loggedIn(auth)) {
            User u = userRepository.findByUsername(auth.getName()).orElse(null);
            if (u != null) {
                prefillName = u.getUsername();
                prefillEmail = u.getEmail();
            }
        }
        model.addAttribute("success", false);
        model.addAttribute("errors", List.of());
        model.addAttribute("formName", prefillName);
        model.addAttribute("formEmail", prefillEmail);
        model.addAttribute("formSubject", "");
        model.addAttribute("formMessage", "");
        return "contact";
    }

    @PostMapping({"/contact.php", "/contact"})
    public String submitContact(@RequestParam(defaultValue = "") String name,
                                @RequestParam(defaultValue = "") String email,
                                @RequestParam(defaultValue = "") String subject,
                                @RequestParam(defaultValue = "") String message,
                                Authentication auth,
                                Model model) {
        String cleanName = name.trim();
        String cleanEmail = email.trim();
        String cleanSubject = subject.trim();
        String cleanMessage = message.trim();

        List<String> errors = new ArrayList<>();
        if (cleanName.isEmpty()) errors.add("Please enter your name.");
        if (cleanEmail.isEmpty() || !EMAIL_PATTERN.matcher(cleanEmail).matches()) {
            errors.add("Please enter a valid email address.");
        }
        if (cleanMessage.isEmpty()) errors.add("Please enter a message.");

        if (!errors.isEmpty()) {
            model.addAttribute("success", false);
            model.addAttribute("errors", errors);
            model.addAttribute("formName", cleanName);
            model.addAttribute("formEmail", cleanEmail);
            model.addAttribute("formSubject", cleanSubject);
            model.addAttribute("formMessage", cleanMessage);
            return "contact";
        }

        Contact c = new Contact();
        c.setName(cleanName);
        c.setEmail(cleanEmail);
        c.setSubject(cleanSubject);
        c.setMessage(cleanMessage);
        contactRepository.save(c);

        model.addAttribute("success", true);
        model.addAttribute("errors", List.of());
        model.addAttribute("formName", loggedIn(auth) ? cleanName : "");
        model.addAttribute("formEmail", loggedIn(auth) ? cleanEmail : "");
        model.addAttribute("formSubject", "");
        model.addAttribute("formMessage", "");
        return "contact";
    }

    @GetMapping({"/login.php", "/login"})
    public String loginPage(@RequestParam(required = false) String error, Model model) {
        model.addAttribute("error", error != null ? "Invalid username or password." : "");
        return "login";
    }

    @GetMapping({"/signup.php", "/signup"})
    public String signupPage(Model model) {
        model.addAttribute("errors", List.of());
        model.addAttribute("success", false);
        model.addAttribute("formUsername", "");
        model.addAttribute("formEmail", "");
        return "signup";
    }

    @PostMapping({"/signup.php", "/signup"})
    public String signupSubmit(@RequestParam(defaultValue = "") String username,
                               @RequestParam(defaultValue = "") String email,
                               @RequestParam(defaultValue = "") String password,
                               @RequestParam(name = "confirm_password", defaultValue = "") String confirmPassword,
                               Model model) {
        String cleanUser = username.trim();
        String cleanEmail = email.trim();
        List<String> errors = new ArrayList<>();

        if (cleanUser.isEmpty()) errors.add("Please enter a username.");
        if (cleanEmail.isEmpty() || !EMAIL_PATTERN.matcher(cleanEmail).matches()) {
            errors.add("Please enter a valid email address.");
        }
        if (password.length() < 4) errors.add("Password must be at least 4 characters.");
        if (!password.equals(confirmPassword)) errors.add("Passwords do not match.");

        if (errors.isEmpty()) {
            if (userRepository.existsByUsernameOrEmail(cleanUser, cleanEmail)) {
                errors.add("That username or email is already registered.");
            } else {
                User user = new User();
                user.setUsername(cleanUser);
                user.setEmail(cleanEmail);
                user.setPassword(passwordEncoder.encode(password));
                user.setRole(User.Role.user);
                userRepository.save(user);
                model.addAttribute("errors", List.of());
                model.addAttribute("success", true);
                model.addAttribute("formUsername", "");
                model.addAttribute("formEmail", "");
                return "signup";
            }
        }

        model.addAttribute("errors", errors);
        model.addAttribute("success", false);
        model.addAttribute("formUsername", cleanUser);
        model.addAttribute("formEmail", cleanEmail);
        return "signup";
    }

    @GetMapping({"/portfolio.php", "/portfolio"})
    public String portfolioPage(Authentication auth, Model model) {
        User user = requireCurrentUser(auth);
        List<Portfolio> rawPortfolios = portfolioRepository.findByUserId(user.getId());
        List<PortfolioView> portfolios = new ArrayList<>();

        for (Portfolio p : rawPortfolios) {
            List<Stock> rawStocks = stockRepository.findByPortfolioIdOrderBySymbolAsc(p.getId());
            List<StockView> stockViews = new ArrayList<>();
            BigDecimal totalInvestment = BigDecimal.ZERO;
            int totalUnits = 0;

            for (Stock s : rawStocks) {
                BigDecimal inv = s.getBuyPrice().multiply(BigDecimal.valueOf(s.getQuantity()));
                totalInvestment = totalInvestment.add(inv);
                totalUnits += s.getQuantity();
                String pType = s.getPurchaseType() != null ? s.getPurchaseType() : "Secondary";
                stockViews.add(new StockView(
                        s.getId(),
                        s.getSymbol().toUpperCase(),
                        pType,
                        pType.toLowerCase(),
                        s.getQuantity(),
                        s.getBuyPrice(),
                        inv,
                        s.getBuyDate() != null ? s.getBuyDate().toString() : "",
                        s.getSoldUnits(),
                        s.getSoldValue(),
                        s.getQuantity() == 0
                ));
            }

            BigDecimal realized = p.getTotalRealizedProfit() != null ? p.getTotalRealizedProfit() : BigDecimal.ZERO;
            String realizedClass = "neutral";
            String realizedLabel = "Realized P/L";
            if (realized.compareTo(BigDecimal.ZERO) > 0) {
                realizedClass = "positive";
                realizedLabel = "Realized Profit";
            } else if (realized.compareTo(BigDecimal.ZERO) < 0) {
                realizedClass = "negative";
                realizedLabel = "Realized Loss";
            }

            portfolios.add(new PortfolioView(
                    p.getId(),
                    p.getPortfolioName(),
                    p.getPortfolioType().name(),
                    totalInvestment,
                    totalUnits,
                    p.getTotalSoldValue(),
                    realized,
                    realized.abs(),
                    realizedLabel,
                    realizedClass,
                    stockViews
            ));
        }

        model.addAttribute("username", user.getUsername());
        model.addAttribute("portfolios", portfolios);
        model.addAttribute("todayDate", LocalDate.now().toString());
        return "portfolio";
    }

    @PostMapping("/add_portfolio.php")
    public String addPortfolio(@RequestParam(name = "portfolio_name", defaultValue = "") String portfolioName,
                               @RequestParam(name = "portfolio_type", defaultValue = "personal") String portfolioType,
                               Authentication auth) {
        User user = requireCurrentUser(auth);
        String name = portfolioName.trim();
        if (!name.isEmpty()) {
            try {
                Portfolio p = new Portfolio();
                p.setUserId(user.getId());
                p.setPortfolioName(name);
                p.setPortfolioType("institutional".equalsIgnoreCase(portfolioType)
                        ? Portfolio.PortfolioType.institutional
                        : Portfolio.PortfolioType.personal);
                portfolioRepository.save(p);
            } catch (Exception ex) {
                return "redirect:/portfolio.php?error=duplicate_portfolio";
            }
        }
        return "redirect:/portfolio.php";
    }

    @GetMapping("/edit_portfolio.php")
    public String editPortfolioForm(@RequestParam Integer id, Authentication auth, Model model) {
        User user = requireCurrentUser(auth);
        Portfolio portfolio = portfolioRepository.findByIdAndUserId(id, user.getId())
                .orElseThrow(() -> new IllegalArgumentException("Portfolio not found or access denied."));
        model.addAttribute("portfolio", portfolio);
        return "edit_portfolio";
    }

    @PostMapping("/edit_portfolio.php")
    public String editPortfolioSubmit(@RequestParam Integer id,
                                      @RequestParam(name = "portfolio_name", defaultValue = "") String portfolioName,
                                      @RequestParam(name = "portfolio_type", defaultValue = "personal") String portfolioType,
                                      Authentication auth) {
        User user = requireCurrentUser(auth);
        Portfolio p = portfolioRepository.findByIdAndUserId(id, user.getId())
                .orElseThrow(() -> new IllegalArgumentException("Portfolio not found or access denied."));
        p.setPortfolioName(portfolioName.trim());
        p.setPortfolioType("institutional".equalsIgnoreCase(portfolioType)
                ? Portfolio.PortfolioType.institutional
                : Portfolio.PortfolioType.personal);
        portfolioRepository.save(p);
        return "redirect:/portfolio.php";
    }

    @GetMapping("/delete_portfolio.php")
    public String deletePortfolioConfirm(@RequestParam Integer id, Authentication auth, Model model) {
        User user = requireCurrentUser(auth);
        Portfolio portfolio = portfolioRepository.findByIdAndUserId(id, user.getId()).orElse(null);
        if (portfolio == null) return "redirect:/portfolio.php";
        long stockCount = stockRepository.countByPortfolioId(portfolio.getId());
        model.addAttribute("portfolio", portfolio);
        model.addAttribute("stockCount", stockCount);
        model.addAttribute("deleteError", null);
        return "delete_portfolio";
    }

    @PostMapping("/delete_portfolio.php")
    public String deletePortfolioSubmit(@RequestParam Integer id, Authentication auth) {
        User user = requireCurrentUser(auth);
        portfolioService.deletePortfolio(user.getId(), id);
        return "redirect:/portfolio.php?status=portfolio_deleted";
    }

    @GetMapping({"/export_portfolio.php", "/export_portfolio"})
    public ResponseEntity<byte[]> exportPortfolioCsv(@RequestParam(required = false) Integer id, Authentication auth) {
        User user = requireCurrentUser(auth);
        List<Portfolio> all = portfolioRepository.findByUserId(user.getId());
        List<Portfolio> selected = id != null
                ? all.stream().filter(p -> p.getId().equals(id)).toList()
                : all;

        StringBuilder sb = new StringBuilder();
        sb.append("Portfolio,Type,Symbol,Purchase Type,Quantity,Avg Buy Price,Investment,Sold Units,Sold Value,Realized Profit,Buy Date\r\n");
        for (Portfolio p : selected) {
            List<Stock> stocks = stockRepository.findByPortfolioIdOrderBySymbolAsc(p.getId());
            if (stocks.isEmpty()) {
                sb.append(csvCell(p.getPortfolioName())).append(',')
                  .append(csvCell(p.getPortfolioType().name())).append(',')
                  .append("-,-,0,0.00,0.00,0,")
                  .append(p.getTotalSoldValue()).append(',')
                  .append(p.getTotalRealizedProfit()).append(",-\r\n");
                continue;
            }
            for (Stock s : stocks) {
                BigDecimal inv = s.getBuyPrice().multiply(BigDecimal.valueOf(s.getQuantity()));
                sb.append(csvCell(p.getPortfolioName())).append(',')
                  .append(csvCell(p.getPortfolioType().name())).append(',')
                  .append(csvCell(s.getSymbol())).append(',')
                  .append(csvCell(s.getPurchaseType())).append(',')
                  .append(s.getQuantity()).append(',')
                  .append(s.getBuyPrice()).append(',')
                  .append(inv).append(',')
                  .append(s.getSoldUnits()).append(',')
                  .append(s.getSoldValue()).append(',')
                  .append(p.getTotalRealizedProfit()).append(',')
                  .append(csvCell(s.getBuyDate() != null ? s.getBuyDate().toString() : "-")).append("\r\n");
            }
        }

        String safeName = (id != null && !selected.isEmpty())
                ? selected.get(0).getPortfolioName().replaceAll("[^a-zA-Z0-9_-]+", "_")
                : "all_portfolios";

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"myshareapp_" + safeName + ".csv\"")
                .contentType(new MediaType("text", "csv", StandardCharsets.UTF_8))
                .body(sb.toString().getBytes(StandardCharsets.UTF_8));
    }

    @PostMapping("/add_stock.php")
    public String addStock(@RequestParam(name = "portfolio_id") Integer portfolioId,
                           @RequestParam String symbol,
                           @RequestParam(name = "purchase_type", defaultValue = "Secondary") String purchaseType,
                           @RequestParam Integer quantity,
                           @RequestParam(name = "buy_price", required = false) BigDecimal buyPrice,
                           @RequestParam(name = "buy_date", required = false) String buyDateStr,
                           Authentication auth) {
        User user = requireCurrentUser(auth);
        LocalDate buyDate = (buyDateStr != null && !buyDateStr.isBlank()) ? LocalDate.parse(buyDateStr) : LocalDate.now();
        stockService.addStock(
                user.getId(),
                portfolioId,
                symbol,
                purchaseType,
                quantity,
                buyPrice != null ? buyPrice : BigDecimal.ZERO,
                buyDate
        );
        return "redirect:/portfolio.php";
    }

    @GetMapping("/edit_stock.php")
    public String editStockForm(@RequestParam Integer id, Authentication auth, Model model) {
        User user = requireCurrentUser(auth);
        Stock stock = stockRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Stock not found."));
        portfolioRepository.findByIdAndUserId(stock.getPortfolioId(), user.getId())
                .orElseThrow(() -> new IllegalArgumentException("Access denied."));
        model.addAttribute("stock", stock);
        return "edit_stock";
    }

    @PostMapping("/edit_stock.php")
    public String editStockSubmit(@RequestParam Integer id,
                                  @RequestParam String symbol,
                                  @RequestParam(name = "purchase_type", defaultValue = "Secondary") String purchaseType,
                                  @RequestParam Integer quantity,
                                  @RequestParam(name = "buy_price", required = false) BigDecimal buyPrice,
                                  @RequestParam(name = "buy_date", required = false) String buyDateStr,
                                  Authentication auth) {
        User user = requireCurrentUser(auth);
        LocalDate buyDate = (buyDateStr != null && !buyDateStr.isBlank()) ? LocalDate.parse(buyDateStr) : null;
        stockService.editStock(
                user.getId(),
                id,
                symbol,
                purchaseType,
                quantity,
                buyPrice != null ? buyPrice : BigDecimal.ZERO,
                buyDate
        );
        return "redirect:/portfolio.php";
    }

    @GetMapping("/delete_stock.php")
    public String deleteStock(@RequestParam Integer id, Authentication auth) {
        User user = requireCurrentUser(auth);
        stockService.deleteStock(user.getId(), id);
        return "redirect:/portfolio.php";
    }

    @PostMapping("/sell_stock.php")
    public String sellStock(@RequestParam(name = "stock_id") Integer stockId,
                            @RequestParam(name = "sell_quantity") Integer sellQuantity,
                            @RequestParam(name = "sell_price") BigDecimal sellPrice,
                            @RequestParam(name = "sell_date", required = false) String sellDateStr,
                            Authentication auth) {
        User user = requireCurrentUser(auth);
        LocalDate sellDate = (sellDateStr != null && !sellDateStr.isBlank()) ? LocalDate.parse(sellDateStr) : LocalDate.now();
        stockService.sellStock(user.getId(), stockId, sellQuantity, sellPrice, sellDate);
        return "redirect:/portfolio.php";
    }

    private String csvCell(String val) {
        String s = val == null ? "" : val;
        if (s.contains(",") || s.contains("\"") || s.contains("\n") || s.contains("\r")) {
            return "\"" + s.replace("\"", "\"\"") + "\"";
        }
        return s;
    }
}
