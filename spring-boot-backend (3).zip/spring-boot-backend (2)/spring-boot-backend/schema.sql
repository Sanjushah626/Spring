CREATE DATABASE IF NOT EXISTS myshareapp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE myshareapp;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'user') NOT NULL DEFAULT 'user',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS portfolios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    portfolio_name VARCHAR(100) NOT NULL,
    portfolio_type ENUM('personal', 'institutional') NOT NULL DEFAULT 'personal',
    total_sold_value DECIMAL(15, 2) NOT NULL DEFAULT 0.00,
    total_realized_profit DECIMAL(15, 2) NOT NULL DEFAULT 0.00,
    UNIQUE KEY unique_user_portfolio (user_id, portfolio_name),
    CONSTRAINT fk_portfolios_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS stocks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    portfolio_id INT NOT NULL,
    symbol VARCHAR(20) NOT NULL,
    purchase_type VARCHAR(20) NOT NULL DEFAULT 'Secondary',
    quantity INT NOT NULL DEFAULT 0,
    buy_price DECIMAL(15, 2) NOT NULL DEFAULT 0.00,
    buy_date DATE NULL,
    sold_quantity INT NOT NULL DEFAULT 0,
    sold_value DECIMAL(18, 2) NOT NULL DEFAULT 0.00,
    sold_units INT NOT NULL DEFAULT 0,
    CONSTRAINT fk_stocks_portfolio FOREIGN KEY (portfolio_id) REFERENCES portfolios(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS sold_stocks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    portfolio_id INT NOT NULL,
    stock_id INT NOT NULL,
    symbol VARCHAR(20) NOT NULL,
    quantity_sold INT NOT NULL,
    buy_price DECIMAL(15, 2) NOT NULL,
    sell_price DECIMAL(18, 2) NOT NULL,
    investment_cost DECIMAL(15, 2) NOT NULL,
    sale_value DECIMAL(15, 2) NOT NULL,
    broker_charge DECIMAL(15, 2) NOT NULL DEFAULT 0.00,
    sebon_charge DECIMAL(15, 2) NOT NULL DEFAULT 0.00,
    dp_charge DECIMAL(18, 2) NOT NULL DEFAULT 0.00,
    capital_gain_tax DECIMAL(18, 2) NOT NULL DEFAULT 0.00,
    net_profit DECIMAL(18, 2) NOT NULL,
    sell_date DATE NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_sold_stocks_portfolio FOREIGN KEY (portfolio_id) REFERENCES portfolios(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS news (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(255),
    description TEXT,
    image VARCHAR(255),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS contacts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100),
    subject VARCHAR(255),
    message TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

INSERT IGNORE INTO users (id, username, email, password, role, created_at) VALUES
(1, 'suraj', 'suraj@gmail.com', '$2y$10$Ul5lxvW2z7ITKv4qj.vHVOf2YnuY2znk.KCTtZbfGC6BZTmRUGlj6', 'admin', '2026-07-11 07:28:22'),
(3, 'sanju', 'sanju@gmail.com', '$2y$10$vFb.mTgNYy5.U3pP6OZ/qe4aurrTDsR/dQKL0CgmeutdnMvNnUWny', 'user', '2026-07-11 07:49:01'),
(6, 'sarika', 'sarika@gmail.com', '$2y$10$BZ3CILqoyaPLV7tyOGIXT.yo3nOG2/lEmd2Li14aD8USG1be7rLWq', 'user', '2026-07-17 14:53:59'),
(7, 'user', 'user@gmail.com', '$2y$10$nlbDR6QRL6VuvVSe3.4LHu2hBU6BZrHv9wKEmpmHhtDyZ2sWKF9My', 'user', '2026-10-26 08:48:10');

INSERT IGNORE INTO portfolios (id, user_id, portfolio_name, portfolio_type, total_sold_value, total_realized_profit) VALUES
(2, 3, 'longterm', 'personal', 35600.00, 5033.39),
(3, 6, 'sarika', 'personal', 254000.00, -467275.45),
(4, 6, 'pcil', 'personal', 0.00, 0.00),
(5, 3, 'test', 'personal', 0.00, 0.00),
(7, 7, 'longterm', 'personal', 0.00, 0.00);

INSERT IGNORE INTO stocks (id, portfolio_id, symbol, purchase_type, quantity, buy_price, buy_date, sold_quantity, sold_value, sold_units) VALUES
(2, 2, 'PHCL', 'Secondary', 400, 261.30, '2026-01-08', 0, 0.00, 0),
(5, 3, 'EBL', 'Secondary', 0, 198.00, NULL, 0, 54000.00, 100),
(6, 2, 'MEHL', 'Secondary', 0, 300.00, NULL, 0, 35600.00, 100),
(7, 3, 'ANLB', 'Secondary', 100, 6980.00, NULL, 0, 200000.00, 100),
(8, 4, 'PCIL', 'IPO', 10, 100.00, NULL, 0, 0.00, 0),
(9, 2, 'SOPL', 'IPO', 10, 100.00, NULL, 0, 0.00, 0),
(10, 5, 'AHPC', 'Secondary', 145, 254.00, NULL, 0, 0.00, 0),
(12, 7, 'PHCL', 'Secondary', 400, 258.00, NULL, 0, 0.00, 0);

INSERT IGNORE INTO sold_stocks (id, portfolio_id, stock_id, symbol, quantity_sold, buy_price, sell_price, investment_cost, sale_value, broker_charge, sebon_charge, dp_charge, capital_gain_tax, net_profit, sell_date, created_at) VALUES
(2, 3, 5, 'EBL', 100, 198.00, 540.00, 19800.00, 54000.00, 178.20, 8.10, 25.00, 2549.15, 31439.55, '2026-07-17', '2026-07-17 15:04:50'),
(3, 2, 6, 'MEHL', 100, 300.00, 356.00, 30000.00, 35600.00, 128.16, 5.34, 25.00, 408.11, 5033.39, '2026-07-18', '2026-07-18 08:59:55'),
(4, 3, 7, 'ANLB', 100, 6980.00, 2000.00, 698000.00, 200000.00, 660.00, 30.00, 25.00, 0.00, -498715.00, '2026-07-28', '2026-07-28 16:51:48');

INSERT IGNORE INTO news (id, user_id, title, description, image, created_at) VALUES
(7, 1, 'Nepal SBI Bank Announces 8.25% Dividend for FY 2082/83', 'Nepal SBI Bank has announced an 8.25% dividend for its shareholders, consisting of 3.4% bonus shares and 4.85% cash dividend.', 'news_6a68dac04ed79.jpg', '2026-11-13 16:30:00'),
(8, 1, 'Super Mai Hydropower Announces 18.421% Dividend', 'Super Mai Hydropower has proposed an 18.421% dividend for FY 2082/83, including 14% bonus shares and 4.421% cash dividend.', NULL, '2026-11-13 16:31:17'),
(9, 1, 'Unilever Nepal Announces 1540% Cash Dividend', 'Unilever Nepal has recommended a 1540% cash dividend for FY 2082/83, equivalent to Rs. 1,540 per equity share.', NULL, '2026-11-13 16:33:04'),
(10, 1, 'Api Power Announces 5.2632% Dividend', 'Api Power Company has proposed a 5.2632% total dividend for FY 2082/83, consisting of 5% bonus shares and 0.2632% cash dividend.', NULL, '2026-11-13 16:33:49'),
(11, 1, 'Chhimek Laghubitta Announces 25% Dividend', 'Chhimek Laghubitta has declared a 25% dividend for FY 2082/83, comprising 11.9631% bonus shares and 13.0369% cash dividend.', NULL, '2026-11-13 16:34:12');

INSERT IGNORE INTO contacts (id, name, email, subject, message, created_at) VALUES
(1, 'sanju', 'sanju@gmail.com', 'test', 'testing if it is working or not', '2026-07-11 07:49:35'),
(2, 'sanju', 'sanju@gmail.com', 'upload some news', 'news tab is empty upload smoke news', '2026-07-11 07:50:12'),
(4, 'sarika', 'sarika@gmail.com', 'Review', '5 start', '2026-07-17 14:59:01'),
(6, 'sanju', 'ashim@gmail.com', 'ex', 'python cobra sab thin uni', '2026-08-12 09:41:57');
