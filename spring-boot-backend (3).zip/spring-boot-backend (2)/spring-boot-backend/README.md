# MyShareApp — Full-Stack Spring Boot 3 Project

This archive contains the **complete full-stack Spring Boot 3 application** (Thymeleaf frontend + CSS/JS assets + NEPSE Market API + Spring Security + Spring Data JPA + MySQL schema).

## Prerequisites
- **Java 17+** (tested with JDK 17–24)
- **Maven 3.9+**
- **MySQL 8+ / XAMPP MySQL** *(optional — or use the built-in H2 in-memory mode below)*

## Option A — Run with MySQL (Recommended)
1. **Make sure MySQL is running** on `localhost:3306`:
   - If you use **XAMPP**, open XAMPP Control Panel and click **Start** next to **MySQL**.
   - If you use standalone **MySQL Server**, open Windows Services (`services.msc`) and start **MySQL80**.
2. **(Optional)** Import `schema.sql` into MySQL (otherwise Hibernate + `DataSeeder` automatically creates the `myshareapp` database, tables, and seed data on startup):
   ```bash
   mysql -u root -p < schema.sql
   ```
3. If your MySQL `root` user has a password or uses a custom port, set env vars (`DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD`) or edit `src/main/resources/application.properties`.
4. Start the app:
   ```bash
   mvn spring-boot:run
   ```

## Option B — Run Immediately Without MySQL (H2 In-Memory Mode)
If MySQL is not installed or running, start with the built-in `h2` profile (auto-seeds all sample users, portfolios, stocks, news, and contacts in memory):

```bash
mvn spring-boot:run -Dspring-boot.run.profiles=h2
```

Open **`http://localhost:8080`** in your browser.

## Included Frontend & Backend Modules
- **Public Frontend (Thymeleaf + Static Assets)**:
  - `/` and `/hello.html` — NEPSE Dashboard (chart, top traded, gainers, losers, indices, market summary)
  - `/market.html` — Live Market Search, Market Depth & Intraday Chart modals
  - `/news.php` — Market News feed
  - `/contact.php` — Public Contact form
  - `/login.php` & `/signup.php` — Session-based login & account registration (`$2y$` PHP BCrypt compatible)
- **User Portfolio & Stock Management**:
  - `/portfolio.php` — Portfolio metrics, live NEPSE LTP/P&L calculations, Buy/Sell/Edit/Delete stocks, and **CSV Export** (`/export_portfolio.php`)
- **Admin Dashboard (`ROLE_ADMIN`)**:
  - `/dashboard.php`, `/users.php`, `/newss.php`, `/add_news.php`, `/edit_news.php`, `/contacts.php`, `/view_contact.php`
- **REST & Market Endpoints**:
  - `/api/auth/**`, `/api/portfolios/**`, `/api/stocks/**`, `/api/news`, `/api/contacts`, `/api/admin/**`
  - `/IsNepseOpen`, `/DailyNepseIndexGraph`, `/TopTenTradeScrips`, `/TopGainers`, `/TopLosers`, `/NepseIndex`, `/NepseSubIndices`, `/Summary`, `/LiveMarket`, `/PriceVolume`, `/MarketDepth`, `/DailyScripPriceGraph`

## Connecting a Live NEPSE Data Feed
By default, market endpoints return built-in sample NEPSE quotes so the app runs standalone without an external stock server. If you run a local/external NEPSE API server (such as the FastAPI `NepseUnofficialApi` server on `http://127.0.0.1:8000`), set it in `src/main/resources/application.properties`:

```properties
nepse.api.base-url=http://127.0.0.1:8000
```

Spring Boot will automatically proxy live market quotes, indices, charts, and market depth from that server (falling back to sample quotes if unreachable).
